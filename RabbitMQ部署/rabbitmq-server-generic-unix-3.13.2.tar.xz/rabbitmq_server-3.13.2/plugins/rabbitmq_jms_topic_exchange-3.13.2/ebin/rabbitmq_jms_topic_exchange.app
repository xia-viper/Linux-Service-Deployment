{application, 'rabbitmq_jms_topic_exchange', [
	{description, "RabbitMQ JMS topic selector exchange plugin"},
	{vsn, "3.13.2"},
	{id, "v3.13.1-52-gdc25ef5"},
	{modules, ['rabbit_db_jms_exchange','rabbit_db_jms_exchange_m2k_converter','rabbit_jms_topic_exchange','sjx_evaluator']},
	{registered, []},
	{applications, [kernel,stdlib,mnesia,rabbit_common,rabbit,khepri,khepri_mnesia_migration]},
	{optional_applications, []},
	{env, []}
]}.