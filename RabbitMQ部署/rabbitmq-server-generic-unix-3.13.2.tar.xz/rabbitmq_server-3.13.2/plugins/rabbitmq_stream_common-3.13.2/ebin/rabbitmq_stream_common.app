{application, 'rabbitmq_stream_common', [
	{description, "RabbitMQ Stream Common"},
	{vsn, "3.13.2"},
	{id, "v3.13.1-52-gdc25ef5"},
	{modules, ['rabbit_stream_core']},
	{registered, []},
	{applications, [kernel,stdlib]},
	{optional_applications, []},
	{env, [
]}
]}.